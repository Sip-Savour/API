from fastapi import FastAPI, HTTPException
from predict import fast_predict

@app.post("/predict", response_model=WineResponse)
def predict_wine(req: WineRequest):
    """
    Reçoit une description et une couleur.
    Retourne le cépage estimé et la meilleure bouteille.
    """
    try:
        cepage_estime, bouteille_trouvee = fast_predict(req.features, req.color)

        if bouteille_trouvee is None:
            return WineResponse(bottle=None)

        info_bouteille = BottleInfo(
            title=str(bouteille_trouvee.get('title')),
            description=str(bouteille_trouvee.get('description')),
            variety=str(bouteille_trouvee.get('variety')),
            
        )

        return WineResponse(
            bottle=info_bouteille
        )

    except Exception as e:
        print(f"Erreur API Predict : {e}")
        raise HTTPException(status_code=500, detail=str(e))
