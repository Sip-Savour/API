from fastapi import FastAPI, HTTPException
from database import SessionLocal, User, init_db


@app.post("/signup", response_model=UserResponse)
def create_user(user: UserCreate):
    db = SessionLocal()
    try:
        # 1. Vérif email
        existing_user = db.query(User).filter(User.email == user.email).first()
        if existing_user:
            raise HTTPException(status_code=400, detail="Email déjà utilisé.")
        
        # 2. Vérif username
        existing_username = db.query(User).filter(User.username == user.username).first()
        if existing_username:
            raise HTTPException(status_code=400, detail="Nom d'utilisateur déjà pris.")

        # 3. Création
        new_user = User(
            username=user.username,
            email=user.email,
            password_hash=get_password_hash(user.password)
        )
        
        db.add(new_user)
        db.commit()
        db.refresh(new_user)
        
        return new_user

    except HTTPException as he:
        raise he
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Erreur inscription : {str(e)}")
    finally:
        db.close()