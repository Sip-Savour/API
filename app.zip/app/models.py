from pydantic import BaseModel, Field, EmailStr, field_validator

# --- Partie VINS ---
class WineRequest(BaseModel):
    features: str        # Ex: "steak pepper"
    color: str = None    # Ex: "red" (Optionnel)

class BottleInfo(BaseModel):
    title: str
    description: str
    variety: str
    

class WineResponse(BaseModel):
    bottle: BottleInfo | None # Peut être null si aucun résultat

# --- Partie UTILISATEURS (Inscription) ---
class UserCreate(BaseModel):
    username: str
    email: str
    password: str

class UserResponse(BaseModel):
    id: int
    username: str
    email: str
