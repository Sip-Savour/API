from fastapi import FastAPI, HTTPException
import pandas as pd
import numpy as np
import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from predict import fast_predict
from database import SessionLocal, User, init_db
from passlib.context import CryptContext
from sqlalchemy.exc import IntegrityError
from models import *

# ================= CONFIGURATION =================
app = FastAPI(
    title="Sommelier IA API", 
    description="API de recommandation de vin (AutoML + KNN) & Gestion Utilisateurs",
    version="1.0"
)

# Sécurité (Hashage mots de passe)
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def get_password_hash(password):
    return pwd_context.hash(password)

# Initialisation de la DB au démarrage
@app.on_event("startup")
def startup_event():
    print("Démarrage de l'API...")
    init_db() # Crée les tables si elles n'existent pas


# ================= ROUTES (Endpoints) =================

@app.get("/")
def home():
    return {"status": "online", "message": "API opérationnelle."}


